import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ImageBackground,
} from 'react-native';

import { COLORS, FONTS, SHADOWS } from '../../constants/theme';

export default function BecomeProducerCard({ onPress }) {
  return (
    <View style={styles.wrapper}>
      <ImageBackground
        source={require('../../assets/backgrounds/bg_vendor_store.jpg')}
        style={styles.card}
        imageStyle={styles.image}
      >
        <View style={styles.overlay}>
          <View style={styles.textBlock}>
            <Text style={styles.kicker}>For Local Sellers</Text>

            <Text style={styles.title}>
              Bring your products to more people.
            </Text>

            <Text style={styles.body}>
              Reach nearby customers through a warm local marketplace.
            </Text>
          </View>

          <TouchableOpacity
            activeOpacity={0.85}
            style={styles.button}
            onPress={onPress}
          >
            <Text style={styles.buttonText}>
              Become a Producer
            </Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    paddingHorizontal: 20,
    marginBottom: 42,
  },

  card: {
    height: 250,
    borderRadius: 24,
    overflow: 'hidden',
    ...SHADOWS.soft,
  },

  image: {
    borderRadius: 24,
  },

  overlay: {
    flex: 1,
    justifyContent: 'space-between',
    paddingHorizontal: 22,
    paddingTop: 22,
    paddingBottom: 22,
    backgroundColor: 'rgba(0,0,0,0.44)',
  },

  textBlock: {
    flexShrink: 1,
  },

  kicker: {
    color: COLORS.cream,
    fontFamily: FONTS.bodyBold,
    fontSize: 10,
    lineHeight: 14,
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 7,
  },

  title: {
    color: COLORS.white,
    fontFamily: FONTS.bodyBold,
    fontSize: 23,
    lineHeight: 28,
    marginBottom: 9,
    maxWidth: '92%',
  },

  body: {
    color: COLORS.cream,
    fontFamily: FONTS.body,
    fontSize: 14,
    lineHeight: 20,
    maxWidth: '92%',
  },

  button: {
    alignSelf: 'flex-start',
    height: 56,
    paddingHorizontal: 30,
    borderRadius: 28,
    backgroundColor: COLORS.gold,
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.soft,
  },

  buttonText: {
    color: COLORS.brown,
    fontFamily: FONTS.bodyBold,
    fontSize: 15,
  },
});