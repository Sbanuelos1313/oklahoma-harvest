import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  StatusBar,
  SafeAreaView,
  Platform,
  Linking,
  Image,
  ImageBackground,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import { CATEGORIES } from '../constants/categories';
import {
  COLORS,
  FONTS,
  RADIUS,
  SHADOWS,
  COMMON_STYLES,
} from '../constants/theme';

export default function SearchScreen({
  API,
  token,
  user,
  cart,
  setCart,
  navigation,
  route,
}) {
  const [query, setQuery] = useState(
    route?.params?.initialQuery ||
    route?.params?.category ||
    ''
  );

  const [selectedCategory, setSelectedCategory] = useState(
    route?.params?.category || null
  );

  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const featuredCategories = useMemo(
    () => CATEGORIES.slice(0, 12),
    []
  );

  async function doSearch(searchValue = query, categoryValue = selectedCategory) {
    const finalQuery = String(searchValue || '').trim();
    const finalCategory = categoryValue || '';

    if (!finalQuery && !finalCategory) {
      return;
    }

    setLoading(true);
    setSearched(true);

    try {
      const params = new URLSearchParams();

      if (finalQuery) {
        params.append('q', finalQuery);
      }

      if (finalCategory) {
        params.append('category', finalCategory);
      }

      params.append('lat', '35.4676');
      params.append('lng', '-97.5164');

      const response = await fetch(
        `${API}/api/products/search?${params.toString()}`
      );

      if (!response.ok) {
        throw new Error(`Search failed with status ${response.status}`);
      }

      const data = await response.json();
      setResults(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Search error:', error);
      setResults([]);
    } finally {
      setLoading(false);
    }
  }

  function clearSearch() {
    setQuery('');
    setSelectedCategory(null);
    setResults([]);
    setSearched(false);
  }

  function handleCategoryPress(category) {
    const categoryKey = category?.key || category?.title || '';
    const categoryLabel = category?.title || category?.label || '';

    setSelectedCategory(categoryKey);
    setQuery(categoryLabel);

    doSearch(categoryLabel, categoryKey);
  }

  function handleResultPress(item) {
    navigation.navigate('ProductDetail', {
      product: item,
    });
  }

  function handleProducerPress(item) {
    navigation.navigate('Producer', {
      producer: {
        id: item.producer_id,
        shop_name: item.shop_name,
        city: item.city,
        state: item.state,
        avg_rating: item.avg_rating,
        fulfillment_pickup: item.fulfillment_pickup,
        fulfillment_delivery: item.fulfillment_delivery,
        fulfillment_shipping: item.fulfillment_shipping,
      },
    });
  }

  function renderCategory({ item }) {
    const categoryKey = item?.key || item?.title;

    return (
      <TouchableOpacity
        activeOpacity={0.88}
        style={[
          styles.categoryCard,
          selectedCategory === categoryKey &&
            styles.categoryCardSelected,
        ]}
        onPress={() => handleCategoryPress(item)}
      >
        <ImageBackground
          source={item.image}
          style={styles.categoryImage}
          imageStyle={styles.categoryImageStyle}
        >
          <View style={styles.categoryOverlay} />
        </ImageBackground>

        <Text numberOfLines={1} style={styles.categoryText}>
          {item.title}
        </Text>
      </TouchableOpacity>
    );
  }

  function renderProductImage(item) {
    if (item?.image_url) {
      return (
        <Image
          source={{ uri: item.image_url }}
          style={styles.resultImage}
          resizeMode="cover"
        />
      );
    }

    return (
      <View style={styles.resultImagePlaceholder}>
        <Ionicons
          name="leaf-outline"
          size={26}
          color={COLORS.forest}
        />
      </View>
    );
  }

  function renderResult({ item }) {
    const numericPrice = Number(item.price);
    const formattedPrice = Number.isFinite(numericPrice)
      ? `$${numericPrice.toFixed(2)}`
      : item.price || '';

    return (
      <TouchableOpacity
        activeOpacity={0.9}
        style={styles.resultCard}
        onPress={() => handleResultPress(item)}
      >
        {renderProductImage(item)}

        <View style={styles.resultInfo}>
          <Text numberOfLines={1} style={styles.resultName}>
            {item.name}
          </Text>

          <TouchableOpacity
            activeOpacity={0.75}
            onPress={() => handleProducerPress(item)}
          >
            <Text numberOfLines={1} style={styles.resultShop}>
              {item.shop_name}
              {item.city ? ` · ${item.city}` : ''}
            </Text>
          </TouchableOpacity>

          <View style={styles.resultMetaRow}>
            {item.avg_rating ? (
              <View style={styles.ratingRow}>
                <Ionicons
                  name="star"
                  size={13}
                  color={COLORS.gold}
                />

                <Text style={styles.ratingText}>
                  {Number(item.avg_rating).toFixed(1)}
                </Text>
              </View>
            ) : null}

            <Text style={styles.resultPrice}>
              {formattedPrice}
              {item.unit ? ` / ${item.unit}` : ''}
            </Text>
          </View>

          <View style={styles.fulfillmentRow}>
            {item.fulfillment_pickup && (
              <View style={styles.fulfillmentBadge}>
                <Ionicons
                  name="bag-handle-outline"
                  size={13}
                  color={COLORS.forest}
                />

                <Text style={styles.fulfillmentText}>
                  Pickup
                </Text>
              </View>
            )}

            {item.fulfillment_delivery && (
              <View style={styles.fulfillmentBadge}>
                <Ionicons
                  name="car-outline"
                  size={13}
                  color={COLORS.forest}
                />

                <Text style={styles.fulfillmentText}>
                  Delivery
                </Text>
              </View>
            )}

            {item.fulfillment_shipping && (
              <View style={styles.fulfillmentBadge}>
                <Ionicons
                  name="cube-outline"
                  size={13}
                  color={COLORS.forest}
                />

                <Text style={styles.fulfillmentText}>
                  Shipping
                </Text>
              </View>
            )}
          </View>
        </View>

        <Ionicons
          name="chevron-forward"
          size={20}
          color={COLORS.subText}
        />
      </TouchableOpacity>
    );
  }

  const showDiscoveryContent = !searched && !loading;
  const showResults = searched && !loading;

  return (
    <ImageBackground
      source={require('../assets/backgrounds/bg_home.jpg')}
      resizeMode="cover"
      style={styles.background}
      imageStyle={styles.backgroundImage}
    >
      <View style={styles.overlay}>
        <SafeAreaView style={styles.safeArea}>
          <StatusBar barStyle="dark-content" />

          <View style={styles.header}>
            <TouchableOpacity
              activeOpacity={0.85}
              style={styles.iconButton}
              onPress={() => navigation.goBack()}
            >
              <Ionicons
                name="chevron-back"
                size={24}
                color={COLORS.brown}
              />
            </TouchableOpacity>

            <Text style={styles.title}>Discover</Text>

            <TouchableOpacity
              activeOpacity={0.85}
              style={styles.iconButton}
              onPress={() => navigation.navigate('Cart')}
            >
              <Ionicons
                name="bag-outline"
                size={22}
                color={COLORS.brown}
              />
            </TouchableOpacity>
          </View>

          <View style={styles.searchSection}>
            <Text style={styles.searchPrompt}>
              What are you looking for today?
            </Text>

            <View style={styles.searchBar}>
              <Ionicons
                name="search-outline"
                size={23}
                color={COLORS.subText}
              />

              <TextInput
                style={styles.searchInput}
                placeholder="Search products, vendors, and markets"
                placeholderTextColor={COLORS.subText}
                value={query}
                onChangeText={(value) => {
                  setQuery(value);

                  if (!value.trim() && searched) {
                    clearSearch();
                  }
                }}
                onSubmitEditing={() => doSearch()}
                returnKeyType="search"
                autoCorrect={false}
              />

              {query.length > 0 ? (
                <TouchableOpacity
                  activeOpacity={0.8}
                  onPress={clearSearch}
                >
                  <Ionicons
                    name="close-circle"
                    size={22}
                    color={COLORS.subText}
                  />
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  activeOpacity={0.8}
                  style={styles.filterButton}
                >
                  <Ionicons
                    name="options-outline"
                    size={20}
                    color={COLORS.forest}
                  />
                </TouchableOpacity>
              )}
            </View>
          </View>

          {showDiscoveryContent && (
            <FlatList
              data={featuredCategories}
              keyExtractor={(item) => String(item.id)}
              renderItem={renderCategory}
              numColumns={3}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.discoveryContent}
              columnWrapperStyle={styles.categoryRow}
              ListHeaderComponent={
                <View>
                  <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>
                      Popular Categories
                    </Text>
                  </View>
                </View>
              }
              ListFooterComponent={
                <View style={styles.discoveryMessage}>
                  <Ionicons
                    name="basket-outline"
                    size={34}
                    color={COLORS.forest}
                  />

                  <Text style={styles.emptyTitle}>
                    Fresh from local places
                  </Text>

                  <Text style={styles.emptySub}>
                    Search produce, baked goods, meats, flowers,
                    pantry items, handmade goods, and more.
                  </Text>
                </View>
              }
            />
          )}

          {loading && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator
                size="large"
                color={COLORS.forest}
              />

              <Text style={styles.loadingText}>
                Searching local products...
              </Text>
            </View>
          )}

          {showResults && (
            <FlatList
              data={results}
              keyExtractor={(item) => String(item.id)}
              renderItem={renderResult}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.resultsList}
              ListHeaderComponent={
                <View style={styles.resultsHeader}>
                  <View>
                    <Text style={styles.resultsTitle}>
                      Search Results
                    </Text>

                    <Text style={styles.resultsCount}>
                      {results.length}{' '}
                      {results.length === 1 ? 'item' : 'items'} found
                    </Text>
                  </View>

                  <TouchableOpacity
                    activeOpacity={0.8}
                    style={styles.sortButton}
                  >
                    <Ionicons
                      name="swap-vertical-outline"
                      size={17}
                      color={COLORS.forest}
                    />

                    <Text style={styles.sortText}>
                      Sort
                    </Text>
                  </TouchableOpacity>
                </View>
              }
              ListEmptyComponent={
                <View style={styles.emptyResults}>
                  <View style={styles.emptyIcon}>
                    <Ionicons
                      name="search-outline"
                      size={34}
                      color={COLORS.forest}
                    />
                  </View>

                  <Text style={styles.emptyTitle}>
                    No results found
                  </Text>

                  <Text style={styles.emptySub}>
                    Try another product, category, vendor, or market.
                  </Text>

                  <TouchableOpacity
                    activeOpacity={0.85}
                    style={styles.clearButton}
                    onPress={clearSearch}
                  >
                    <Text style={styles.clearButtonText}>
                      Browse Categories
                    </Text>
                  </TouchableOpacity>
                </View>
              }
            />
          )}
        </SafeAreaView>

        <TouchableOpacity
          style={styles.feedbackButton}
          onPress={() =>
            Linking.openURL(
              'https://forms.gle/bUWcVYSsHYb8RQuE6'
            )
          }
          activeOpacity={0.85}
        >
          <Ionicons
            name="chatbubble-ellipses-outline"
            size={16}
            color={COLORS.white}
          />

          <Text style={styles.feedbackText}>
            Feedback
          </Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },

  backgroundImage: {
    opacity: 0.24,
  },

  overlay: {
    flex: 1,
    backgroundColor: 'rgba(247,242,232,0.92)',
  },

  safeArea: {
    ...COMMON_STYLES.safeArea,
    backgroundColor: 'transparent',
  },

  header: {
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  iconButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.9)',
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.soft,
  },

  title: {
    fontFamily: FONTS.display,
    fontSize: 34,
    lineHeight: 40,
    color: COLORS.brown,
  },

  searchSection: {
    paddingHorizontal: 20,
    paddingTop: 4,
    paddingBottom: 20,
  },

  searchPrompt: {
    fontFamily: FONTS.display,
    fontSize: 25,
    lineHeight: 31,
    color: COLORS.brown,
    marginBottom: 14,
  },

  searchBar: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.96)',
    borderRadius: 30,
    paddingLeft: 18,
    paddingRight: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.soft,
  },

  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontFamily: FONTS.body,
    fontSize: 15,
    color: COLORS.brown,
  },

  filterButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: COLORS.cream,
    alignItems: 'center',
    justifyContent: 'center',
  },

  discoveryContent: {
    paddingHorizontal: 20,
    paddingBottom: 145,
  },

  sectionHeader: {
    marginBottom: 14,
  },

  sectionTitle: {
    fontFamily: FONTS.display,
    fontSize: 29,
    lineHeight: 35,
    color: COLORS.brown,
  },

  categoryRow: {
    justifyContent: 'space-between',
  },

  categoryCard: {
    width: '31.5%',
    marginBottom: 18,
  },

  categoryCardSelected: {
    opacity: 0.78,
  },

  categoryImage: {
    width: '100%',
    aspectRatio: 1.16,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: COLORS.cream,
    ...SHADOWS.soft,
  },

  categoryImageStyle: {
    borderRadius: 18,
  },

  categoryOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },

  categoryText: {
    marginTop: 7,
    textAlign: 'center',
    fontFamily: FONTS.bodyBold,
    fontSize: 12,
    lineHeight: 16,
    color: COLORS.brown,
  },

  discoveryMessage: {
    marginTop: 14,
    paddingHorizontal: 24,
    paddingVertical: 26,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.55)',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },

  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 100,
  },

  loadingText: {
    marginTop: 14,
    fontFamily: FONTS.body,
    fontSize: 14,
    color: COLORS.subText,
  },

  resultsList: {
    paddingHorizontal: 20,
    paddingBottom: 145,
  },

  resultsHeader: {
    paddingTop: 4,
    paddingBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  resultsTitle: {
    fontFamily: FONTS.display,
    fontSize: 28,
    lineHeight: 34,
    color: COLORS.brown,
  },

  resultsCount: {
    marginTop: 3,
    fontFamily: FONTS.body,
    fontSize: 13,
    color: COLORS.subText,
  },

  sortButton: {
    height: 40,
    paddingHorizontal: 15,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.8)',
    borderWidth: 1,
    borderColor: COLORS.border,
  },

  sortText: {
    marginLeft: 5,
    fontFamily: FONTS.bodyBold,
    fontSize: 13,
    color: COLORS.forest,
  },

  resultCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.warmWhite,
    borderRadius: 24,
    padding: 12,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.soft,
  },

  resultImage: {
    width: 78,
    height: 78,
    borderRadius: 18,
    marginRight: 13,
    backgroundColor: COLORS.cream,
  },

  resultImagePlaceholder: {
    width: 78,
    height: 78,
    borderRadius: 18,
    backgroundColor: COLORS.cream,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 13,
  },

  resultInfo: {
    flex: 1,
    paddingRight: 8,
  },

  resultName: {
    fontFamily: FONTS.bodyBold,
    fontSize: 16,
    lineHeight: 20,
    color: COLORS.brown,
    marginBottom: 3,
  },

  resultShop: {
    fontFamily: FONTS.body,
    fontSize: 12,
    lineHeight: 16,
    color: COLORS.subText,
    marginBottom: 5,
  },

  resultMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 7,
  },

  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 10,
  },

  ratingText: {
    marginLeft: 3,
    fontFamily: FONTS.bodyBold,
    fontSize: 12,
    color: COLORS.brown,
  },

  resultPrice: {
    fontFamily: FONTS.bodyBold,
    fontSize: 15,
    color: COLORS.forest,
  },

  fulfillmentRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },

  fulfillmentBadge: {
    height: 26,
    paddingHorizontal: 8,
    borderRadius: 13,
    marginRight: 5,
    marginBottom: 3,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(74,103,65,0.11)',
  },

  fulfillmentText: {
    marginLeft: 4,
    fontFamily: FONTS.bodyBold,
    fontSize: 10,
    color: COLORS.forest,
  },

  emptyResults: {
    paddingHorizontal: 24,
    paddingVertical: 48,
    alignItems: 'center',
  },

  emptyIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: 'rgba(74,103,65,0.11)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
  },

  emptyTitle: {
    fontFamily: FONTS.display,
    fontSize: 25,
    lineHeight: 31,
    color: COLORS.brown,
    textAlign: 'center',
    marginTop: 10,
    marginBottom: 8,
  },

  emptySub: {
    fontFamily: FONTS.body,
    fontSize: 14,
    lineHeight: 21,
    color: COLORS.subText,
    textAlign: 'center',
  },

  clearButton: {
    height: 50,
    marginTop: 20,
    paddingHorizontal: 24,
    borderRadius: 25,
    backgroundColor: COLORS.gold,
    alignItems: 'center',
    justifyContent: 'center',
  },

  clearButtonText: {
    fontFamily: FONTS.bodyBold,
    fontSize: 14,
    color: COLORS.brown,
  },

  feedbackButton: {
    position: 'absolute',
    bottom: Platform.OS === 'ios' ? 92 : 78,
    right: 18,
    zIndex: 999,
    height: 44,
    paddingHorizontal: 16,
    borderRadius: 22,
    backgroundColor: COLORS.forest,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.medium,
  },

  feedbackText: {
    marginLeft: 6,
    fontFamily: FONTS.bodyBold,
    fontSize: 13,
    color: COLORS.white,
  },
});